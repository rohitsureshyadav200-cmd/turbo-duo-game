# Turbo Duo — Multiplayer Racing Challenge

A two-player, room-code racing game designed for mobile and desktop browsers.

## Publish
1. Upload this complete ZIP to Netlify Drop: https://app.netlify.com/drop
2. Wait for the deployment to finish and open the assigned HTTPS URL.
3. Open the URL, choose **Create a room**, and send the invite link to another player.
4. Both players tap **Ready for next round** to begin; hold **Accelerate** to race.

## Important
This is a starter implementation. Before treating it as a production game, run a full two-device test. The current simple room writes are not a transactional multiplayer lock, so simultaneous actions can race; production-grade scoring should use conditional writes or a database transaction. Netlify Blobs requires the deployed site to be linked to a Netlify account.
