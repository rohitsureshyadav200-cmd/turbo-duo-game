import { getStore } from "@netlify/blobs";

const store = getStore({ name: "turbo-duo-games", consistency: "strong" });
const json = (data: unknown, statusCode = 200) => new Response(JSON.stringify(data), {
  status: statusCode, headers: { "content-type": "application/json", "cache-control": "no-store" }
});
type Player = { id: string; name: string; score: number; ready: boolean };
type Game = { roomId: string; players: Player[]; round: number; status: string; progress: Record<string, number>; winnerName?: string; updatedAt: number };
const key = (roomId: string) => `room:${roomId}`;
async function load(roomId: string): Promise<Game | null> {
  return await store.get(key(roomId), { type: "json", consistency: "strong" }) as Game | null;
}
async function save(game: Game) { game.updatedAt = Date.now(); await store.setJSON(key(game.roomId), game); }
export default async (req: Request) => {
  if (req.method !== "POST") return json({ error: "Use POST" }, 405);
  let body: any;
  try { body = await req.json(); } catch { return json({ error: "Invalid JSON" }, 400); }
  const { action, roomId, playerId, name, amount } = body || {};
  if (!/^[A-Z0-9]{4,8}$/.test(roomId || "") || !/^[A-Za-z0-9_-]{3,12}$/.test(playerId || "")) {
    // Create/join still require a client player ID.
    if (action !== "create" && action !== "join") return json({ error: "Invalid room or player ID" }, 400);
  }
  if (!roomId || !playerId) return json({ error: "Room and player ID are required" }, 400);
  try {
    let game = await load(roomId);
    if (action === "create") {
      if (!game) game = { roomId, players: [], round: 1, status: "waiting", progress: {}, updatedAt: Date.now() };
      if (!game.players.some(p => p.id === playerId) && game.players.length < 2) game.players.push({ id: playerId, name: String(name || "Racer").slice(0,16), score: 0, ready: false });
      await save(game); return json({ state: game });
    }
    if (action === "join") {
      if (!game) return json({ error: "Room not found. Ask the host to create it first." }, 404);
      if (!game.players.some(p => p.id === playerId)) {
        if (game.players.length >= 2) return json({ error: "This room is full." }, 409);
        game.players.push({ id: playerId, name: String(name || "Racer").slice(0,16), score: 0, ready: false });
      }
      if (game.players.length === 2) game.status = "lobby";
      await save(game); return json({ state: game });
    }
    if (!game) return json({ error: "Room not found." }, 404);
    if (!game.players.some(p => p.id === playerId)) return json({ error: "You are not in this room." }, 403);
    if (action === "get") return json({ state: game });
    if (action === "ready") {
      const player = game.players.find(p => p.id === playerId)!; player.ready = true;
      if (game.players.length === 2 && game.players.every(p => p.ready)) {
        if (game.status === "roundover") { game.round += 1; game.winnerName = undefined; }
        game.status = "racing"; game.progress = {};
      }
      await save(game); return json({ state: game });
    }
    if (action === "advance") {
      if (game.status !== "racing") return json({ state: game });
      const p = game.progress[playerId] || 0; game.progress[playerId] = Math.min(100, p + Math.max(1, Math.min(5, Number(amount) || 2)));
      const finishers = game.players.filter(p => (game.progress[p.id] || 0) >= 100);
      if (finishers.length) {
        const winner = finishers[0]; winner.score += 1; game.status = game.round >= 3 ? "finished" : "roundover";
        game.winnerName = winner.name;
      }
      await save(game); return json({ state: game });
    }
    return json({ error: "Unknown action" }, 400);
  } catch (e) { return json({ error: "Game service error. Please retry." }, 500); }
};
